<footer class="main-footer">
    <strong>Copyright &copy; 2023 <a href="#">Mutiara</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
        <b>Version</b> 1.0.0
    </div>
</footer>
<?php /**PATH C:\laragon\www\mutiara\resources\views/components/widget/footer.blade.php ENDPATH**/ ?>