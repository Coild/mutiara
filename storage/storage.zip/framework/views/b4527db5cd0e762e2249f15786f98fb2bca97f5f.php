<?php if (isset($component)) { $__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layout::class, []); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php if (isset($component)) { $__componentOriginalc0d7017c1e21a10ebd81912a450b60a5e7f1277d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Item\Pageheader::class, []); ?>
<?php $component->withName('item.pageheader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
         <?php $__env->slot('name', null, []); ?>  Riwayat  <?php $__env->endSlot(); ?>    
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc0d7017c1e21a10ebd81912a450b60a5e7f1277d)): ?>
<?php $component = $__componentOriginalc0d7017c1e21a10ebd81912a450b60a5e7f1277d; ?>
<?php unset($__componentOriginalc0d7017c1e21a10ebd81912a450b60a5e7f1277d); ?>
<?php endif; ?>
<div class="card">
    <div class="card-body">
        <div class="row">
            <div class="col-md-7"></div>
            <div class="col-md-5">
                <form action="<?php echo e(route('riwayat.filter')); ?>" method="post">
                    <div class="row">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="filter" value="1">
                        <div class="col-md-5">
                            <input type="date" name="start_date" class="form-control" value="<?php echo e(date('Y-m-d')); ?>" required/>
                        </div>
                        <div class="col-md-5">
                            <input type="date" name="end_date" class="form-control" value="<?php echo e(date('Y-m-d')); ?>" required/>
                        </div>
                        <div class="col-md-2">
                            <button class="btn btn-outline-primary" type="submit">Submit</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <table class="table">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Pembeli</th>
                    <th>Kode</th>
                    <th>Kode Tagihan</th>
                    <th>Total</th>
                    
                    
                    
                    <th>Tanggal Transaksi</th>
                    <th>Detail</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $total=0;
                ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <?php
                        $total+=$item['total'];
                    ?>
                    <td><?php echo e($loop->index+1); ?></td>
                    <td><?php echo e($item['name']); ?></td>
                    <td><?php echo e($item['code']); ?></td>
                    <td><?php echo e($item['bill_code']); ?></td>
                    <td><?php echo e('Rp'); ?> <?php echo e(number_format($item['total'], 0, ',', '.')); ?></td>
                    <td><?php echo e($item['date']); ?></td>
                    <td>
                        
                        <button class="btn btn-success" onclick="window.location.href='<?php echo e(route('detil.transaksi')); ?>?id=<?php echo e($item['id']); ?>'"><i class="fa fa-eye">Lihat</i></button>
                        <button class="btn btn-primary" onclick="window.location.href='<?php echo e('/order/invoice/'.$item['id']); ?>'"><i class="fa fa-book">Cetak</i></button>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                
            </tbody>
            <tfoot>
                <tr>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th><?php echo e('Rp'); ?> <?php echo e(number_format($total, 0, ',', '.')); ?></th>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                </tr>
            </tfoot>
        </table>
        
    </div>
</div>    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30)): ?>
<?php $component = $__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30; ?>
<?php unset($__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\mutiara\resources\views/kasir/jual.blade.php ENDPATH**/ ?>