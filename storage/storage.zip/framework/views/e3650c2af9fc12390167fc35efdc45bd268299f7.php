<?php if (isset($component)) { $__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layout::class, ['title' => 'POS']); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <style>
        .tampil-bayar {
            font-size: 5em;
            text-align: center;
            height: 100px;
        }

        .tampil-terbilang {
            padding: 10px;
            background: #f0f0f0;
        }

        .table-pembelian tbody tr:last-child {
            display: none;
        }

        @media(max-width: 768px) {
            .tampil-bayar {
                font-size: 3em;
                height: 70px;
                padding-top: 5px;
            }
        }
    </style>
    <?php if (isset($component)) { $__componentOriginalc0d7017c1e21a10ebd81912a450b60a5e7f1277d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Item\Pageheader::class, []); ?>
<?php $component->withName('item.pageheader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
         <?php $__env->slot('name', null, []); ?>  Penjualan  <?php $__env->endSlot(); ?>    
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc0d7017c1e21a10ebd81912a450b60a5e7f1277d)): ?>
<?php $component = $__componentOriginalc0d7017c1e21a10ebd81912a450b60a5e7f1277d; ?>
<?php unset($__componentOriginalc0d7017c1e21a10ebd81912a450b60a5e7f1277d); ?>
<?php endif; ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('modal.list-produk')->html();
} elseif ($_instance->childHasBeenRendered('0sId5sV')) {
    $componentId = $_instance->getRenderedChildComponentId('0sId5sV');
    $componentTag = $_instance->getRenderedChildComponentTagName('0sId5sV');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('0sId5sV');
} else {
    $response = \Livewire\Livewire::mount('modal.list-produk');
    $html = $response->html();
    $_instance->logRenderedChild('0sId5sV', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <?php $__env->startSection('js'); ?>
        <script>
            $(document).ready(function() {

                const input = document.getElementById("myInput");

                input.addEventListener("keydown", function(event) {
                    if (event.key === "Enter") {
                        event.preventDefault();
                    }
                });

            });
        </script>
    <?php $__env->stopSection(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30)): ?>
<?php $component = $__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30; ?>
<?php unset($__componentOriginalba35371caef1eeddf45260937599d5fd5fb5dd30); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\mutiara\resources\views/kasir/riwayat.blade.php ENDPATH**/ ?>