<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Generate Barcode</title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('dist/css/a4.css')); ?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" />
</head>

<body>
    <?php
        $i = 0;
    ?>

    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $i++;
        ?>
        <?php if($i == 1): ?>
            <div class="page">
        <?php endif; ?>
        <div class="column">
            <table class="col-md-4">

                <thead class="balik" style="width: 150px; height: 15px; font-size: 10px;">
                    <th style=" float:left">
                        <?php echo e($item->barcode); ?>

                    </th>
                </thead style="width: 150px">
                <tr class="balik" style="width: 150px; height:15px">
                    <td>
                        <?php echo '<img src="data:image/png;base64,' .
                            DNS1D::getBarcodePNG($item->barcode, 'C128', 1, 11) .
                            '" alt="barcode"   />'; ?>

                    </td>
                </tr>
                <tr>
                    <td style="border-bottom: 1px solid black;">

                    </td>
                </tr>
                <tr style="height: 15px; font-size: 10px; border-bottom: 1px solid black;">
                    <td style="width: 100px;">
                        <div style="width: 80px;  margin-top: 2px;">
                            <small style="float:left"><?php echo e($item->carat); ?></small>
                            <small style="float:right">%</small>
                        </div>

                    </td>
                </tr>
                <tr style="height: 15px; font-size: 10px; border-bottom: 1px solid black;">
                    <td style="width: 100px;">
                        <div style="width: 80px">
                            <small style="float:left"><?php echo e($item->weight1); ?></small>
                            <small style="float:right">.gr</small>
                        </div>

                    </td>
                </tr>
                <tr style="height: 15px; font-size: 10px; border-bottom: 1px solid black;">
                    <td style="width: 100px;">
                        <div style="width: 80px">
                            <small style="float:left"><?php echo e($item->weight2); ?></small>
                            <small style="float:right">.gr</small>
                        </div>

                    </td>
                </tr>
                <tr style="height: 15px; font-size: 10px;">
                    <td style="width: 100px;">
                        <div style="width: 80px">
                            <small style="float:left">Rp</small>
                            <small style="float:right"><?php echo e(number_format($item->price_sell, 0, ',', '.')); ?></small>
                        </div>

                    </td>
                </tr>
            </table>
        </div>
        <?php if($i % 48 == 0): ?>
            </div>
            <div class="page">
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
</body>

</html>
<?php /**PATH C:\laragon\www\mutiara\resources\views/barcode.blade.php ENDPATH**/ ?>