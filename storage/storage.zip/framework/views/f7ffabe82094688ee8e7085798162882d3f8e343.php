<!-- Content Header (Page header) -->
<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0"><?php echo e($name ?? 'Dashboard'); ?></h1>
            </div><!-- /.col -->
            <div class="col-sm-6 text-right">
                <?php echo e($slot); ?>

            </div>
        </div><!-- /.row -->
    </div><!-- /.container-fluid -->
</div>
<!-- /.content-header -->
<?php /**PATH C:\laragon\www\mutiara\resources\views/components/item/pageheader.blade.php ENDPATH**/ ?>